/**
 * Empty scope.
 * 
 * @namespace Responsiville.Moressette
 */

Responsiville.Moressette = {};