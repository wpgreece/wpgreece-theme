<?php

    /**
     * Contains the necessary functions so that the default WordPress search is
     * extended in order to search inside the values of custom fields.
     * 
     * @author Nevma, http://www.nevma.gr, info@nevma.gr
     * 
     * @license http://www.gnu.org/licenses/gpl-3.0.en.html GPLv3
     */



    /**
     * Joins the posts table with the posts meta table. Meant to be used as a
     * filter callback in order to extend the original database seach SQL query.
     * 
     * @param string $join The original join part of the database search SQL
     *                     query.
     *
     * @return string The join part of the database search SQL query, having
     *                joined the posts table with the posts meta table.
     */
    
    function vanilla_postmeta_search_join ( $join ) {

        global $wpdb;

        if ( is_search() ) {

            $join .= ' LEFT JOIN ' . $wpdb->postmeta. ' ON '. $wpdb->posts . '.ID = ' . $wpdb->postmeta . '.post_id ';

        }
        
        return $join;

    }



    /**
     * Extends the original database seach SQL query in order to take into 
     * account the values of the custom fields of each post. Meant to be used as
     * a filter callback in order to extend the original database seach SQL 
     * query.
     * 
     * @param string $where The original where part of the database search SQL
     *                      query.
     *
     * @return string The where part of the database search SQL query, having
     *                been extended to take into account the values of the
     *                custom fields of each post.
     */
    
    function vanilla_postmeta_search_where ( $where ) {

        global $wpdb;
       
        if ( is_search() ) {

            $postmeta = array();

            $postmeta = apply_filters( 'vanilla_postmeta_keys', $postmeta );

            $and_meta_key_in = '';

            // Case of searching in specific meta keys and not all of them.

            if ( ! empty( $postmeta ) ) {

                $and_meta_key_in = " AND " . $wpdb->postmeta . ".meta_key IN ('" . implode( "', '", $postmeta) . "')";
            }

            $where = preg_replace(
                "/\(\s*" . $wpdb->posts . ".post_title\s+LIKE\s*(\'[^\']+\')\s*\)/",
                "(" . $wpdb->posts . ".post_title LIKE $1) OR (" . $wpdb->postmeta . ".meta_value LIKE $1" . $and_meta_key_in . ")",
                $where
            );

        }

        return $where;

    }



    /**
     * Extends the original database seach SQL query with a distinct clause to
     * prevent duplicates. Meant to be used as a filter callback in order to
     * extend the original database seach SQL query.
     *
     * @return string The where part of the database search SQL query, having
     *                been extended with adistinct clause to prevent duplicates.
     */
    
    function vanilla_postmeta_search_distinct () {

        if ( is_search() ) {

            return "DISTINCT";

        }

        return "";

    }
 


    /**
     * Sets all the necessary filters and hooks so that the default WordPress
     * search is extended in order to search inside the values of custom fields.
     *
     * @return void
     */
    
    function vanilla_postmeta_search_setup () {

        add_filter( 'posts_join', 'vanilla_postmeta_search_join' );
        add_filter( 'posts_where', 'vanilla_postmeta_search_where' );
        add_filter( 'posts_distinct', 'vanilla_postmeta_search_distinct' );

    }
    
?>