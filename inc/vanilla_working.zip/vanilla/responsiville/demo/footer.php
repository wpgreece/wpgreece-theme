            </section> <!-- .content -->



        </main> <!-- .wrapper -->



        <footer class = "footer-credits row">

            <div class = "small-column-100">
                <h3>Created by Nevma.Gr</h3>
                <p>Virtue is a matter of habit. You are what you do. &mdash; A.</p>
             </div>

        </footer> <!-- .footer-credits -->



    </body>

</html>