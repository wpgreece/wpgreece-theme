<!DOCTYPE html>

<html lang = "en">

    <head>



        <meta charset = "utf-8" />
        <meta name = "viewport" content = "width=device-width, initial-scale=1, user-scalable=1, minimal-ui" />
        <meta http-equiv = "X-UA-Compatible" content = "IE=edge,chrome=1" />
        <title>Responsiville &mdash; Grid system, CSS reset, HTML5 framework, by Nevma &copy;</title>
        <link rel = "shortcut icon" type = "image/ico" href = "http://www.nevma.gr/favicon.ico" />



        <!-- Responsiville CSS declarations -->

        <link rel = "stylesheet" type = "text/css" href = "../css/responsiville.def.css" />
        <link rel = "stylesheet" type = "text/css" href = "../css/responsiville.bugsy.css" />
        <link rel = "stylesheet" type = "text/css" href = "../css/responsiville.main.css" />
        <link rel = "stylesheet" type = "text/css" href = "../css/responsiville.moressette.css" />
        <link rel = "stylesheet" type = "text/css" href = "../css/responsiville.ingrid.css" />
        <link rel = "stylesheet" type = "text/css" href = "../css/responsiville.mobimenu.css" />
        <link rel = "stylesheet" type = "text/css" href = "../css/responsiville.megamenu.css" />
        <link rel = "stylesheet" type = "text/css" href = "../css/responsiville.scrollmenu.css" />
        <link rel = "stylesheet" type = "text/css" href = "../css/responsiville.slideshow.css" />
        <link rel = "stylesheet" type = "text/css" href = "../css/responsiville.accordion.css" />
        <link rel = "stylesheet" type = "text/css" href = "../css/responsiville.equalheights.css" />

        <!-- Third party CSS decarlations -->

        <link rel = "stylesheet" type = "text/css" href = "prism/prism.css" />

        <!-- Current page styles -->

        <link rel = "stylesheet" type = "text/css" href = "css/style.css" />



        <!-- Third party Javascript libraries -->

        <script type = "text/javascript" charset = "utf-8" src = "js/jquery-3.1.0.min.js"></script>
        
        <script type = "text/javascript" charset = "utf-8" src = "../../base/js/velocity.min.js"></script>
        <script type = "text/javascript" charset = "utf-8" src = "../../base/js/hammer.min.js"></script>
        <script type = "text/javascript" charset = "utf-8" src = "../../base/js/jquery.hammer.js"></script>

        <script type = "text/javascript" charset = "utf-8" src = "prism/prism.js"></script>

        <!-- Responsiville Javascript files -->

        <script type = "text/javascript" charset = "utf-8" src = "../js/responsiville.def.js"></script>
        <script type = "text/javascript" charset = "utf-8" src = "../js/responsiville.bugsy.js"></script>
        <script type = "text/javascript" charset = "utf-8" src = "../js/responsiville.main.js"></script>
        <script type = "text/javascript" charset = "utf-8" src = "../js/responsiville.moressette.js"></script>
        <script type = "text/javascript" charset = "utf-8" src = "../js/responsiville.ingrid.js"></script>
        <script type = "text/javascript" charset = "utf-8" src = "../js/responsiville.mobimenu.js"></script>
        <script type = "text/javascript" charset = "utf-8" src = "../js/responsiville.megamenu.js"></script>
        <script type = "text/javascript" charset = "utf-8" src = "../js/responsiville.scrollmenu.js"></script>
        <script type = "text/javascript" charset = "utf-8" src = "../js/responsiville.slideshow.js"></script>
        <script type = "text/javascript" charset = "utf-8" src = "../js/responsiville.accordion.js"></script>
        <script type = "text/javascript" charset = "utf-8" src = "../js/responsiville.equalheights.js"></script>

        <!-- Entry script for tests -->

        <script type = "text/javascript">

            Responsiville.Main.AUTO_INIT = true;
            Responsiville.Main.DEBUG     = true;

        </script>

        <script type = "text/javascript" charset = "utf-8" src = "js/functions.js"></script>


    </head>



    <body>

        <main class = "wrapper">

            <header class = "row">



                <div class = "column-100">
                    <h1>Responsiville</h1>
                    <h2>Grid system, CSS reset, HTML5 framework, by Nevma &copy;</h2>
                </div>


                
                <nav class = "navigation main-navigationXXX responsiville-scrollmenu column-100">

                    <ul>
                        <li><a href = "#home">Home</a></li>
                        <li>
                            <a class = "responsiville-megamenu" href = "#grid">The grid</a>
                            <ul>
                                <li><a href = "#grids">The grid</a></li>
                            </ul>
                        </li>
                    </ul>

                </nav>



                <!--
                    Home
                    Info
                        Installing
                        Initialising
                        Settings
                    Grid
                        Grid Elements
                        Clearing floats
                        Grid Building
                    Reset
                        Typography
                        Images
                        Videos & iframes
                        Tables
                        Forms
                    Modules
                        Slideshow
                        Megamenu
                        Mobimenu
                        Scrollmenu
                        Equalheights
                        Accordion


                    Grid showcase
                    Code
                    Element showcase
                -->



            </header>