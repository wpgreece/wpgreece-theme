/**
 * Empty scope.
 * 
 * @namespace Responsiville.Ingrid
 */

Responsiville.Ingrid = {};